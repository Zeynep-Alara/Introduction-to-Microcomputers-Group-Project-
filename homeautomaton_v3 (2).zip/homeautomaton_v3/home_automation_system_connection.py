# home_automation_system_connection.py
# Base UART connection class for the Home Automation project.

import serial


class HomeAutomationSystemConnection:
    """
    Base class that encapsulates low-level UART communication.

    This class is used by higher-level subsystem connections such as
    AirConditionerSystemConnection and CurtainControlSystemConnection.
    """

    def __init__(self, port: str | None = None, baudrate: int = 9600) -> None:
        self.com_port: str | None = port
        self.baud_rate: int = baudrate
        self.serial_conn: serial.Serial | None = None

    # ------------------------------------------------------------------
    # Configuration helpers
    # ------------------------------------------------------------------
    def setComPort(self, port: str) -> None:
        """Set the communication port (e.g., 'COM3' or '/dev/ttyUSB0')."""
        self.com_port = port

    def setBaudRate(self, rate: int) -> None:
        """Set the UART baud rate (default 9600)."""
        self.baud_rate = rate

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------
    def open(self) -> bool:
        """Open the UART serial connection. Returns True on success."""
        if self.com_port is None:
            print("COM port is not set.")
            return False

        try:
            self.serial_conn = serial.Serial(
                self.com_port,
                self.baud_rate,
                timeout=1,
            )
            print(f"Opened serial port {self.com_port} at {self.baud_rate} baud.")
            return True
        except Exception as exc:  # donanım bağlı değilse buraya düşer
            print(f"Failed to open serial port {self.com_port}: {exc}")
            self.serial_conn = None
            return False

    def close(self) -> bool:
        """Close the UART serial connection. Returns True on success."""
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
            print(f"Closed serial port {self.com_port}.")
            return True
        return False

    # ------------------------------------------------------------------
    # Low level helpers
    # ------------------------------------------------------------------
    def _ensure_connection(self) -> bool:
        if self.serial_conn is None or not self.serial_conn.is_open:
            print("Serial connection is not open.")
            return False
        return True

    def _write_byte(self, value: int) -> bool:
        """Send a single command byte over UART."""
        if not self._ensure_connection():
            return False

        try:
            self.serial_conn.write(bytes([value & 0xFF]))
            return True
        except Exception as exc:
            print(f"UART write error: {exc}")
            return False

    def _read_byte(self) -> int | None:
        """Read a single byte from UART, return None on timeout/error."""
        if not self._ensure_connection():
            return None

        try:
            data = self.serial_conn.read(1)
            if len(data) != 1:
                print("UART read timeout.")
                return None
            return data[0]
        except Exception as exc:
            print(f"UART read error: {exc}")
            return None

    def update(self) -> None:
        """Placeholder method for subclasses to override."""
        # Base class does not know what to update.
        pass
