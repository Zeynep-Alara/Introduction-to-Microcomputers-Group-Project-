# air_conditioner_system_connection.py
# High-level API for the Air Conditioner board.

from home_automation_system_connection import HomeAutomationSystemConnection


class AirConditionerSystemConnection(HomeAutomationSystemConnection):
    """
    Implements the PC-side API for the air conditioner subsystem.

    - R2.1.4: Read current desired temperature, ambient temperature
              and fan speed from the board.
    - R2.1.5: Set desired temperature using two 6-bit command bytes
              (10t5..t0 and 11t5..t0) as defined in the project.
    """

    def __init__(self, port: str | None = None, baudrate: int = 9600) -> None:
        super().__init__(port, baudrate)
        self.desiredTemperature: float = 0.0
        self.ambientTemperature: float = 0.0
        self.fanSpeed: int = 0

    # ------------------------------------------------------------------
    # Helpers implementing the UART protocol
    # ------------------------------------------------------------------
    def _read_scaled_value(self, low_cmd: int, high_cmd: int) -> float | None:
        """
        Read a fixed-point value encoded as two 6-bit bytes.

        PIC side returns:
          - low part in response to low_cmd
          - high part in response to high_cmd

        Each byte uses only the lower 6 bits.
        Decoded value: value = high + low / 64.0
        """
        if not self._write_byte(low_cmd):
            return None
        low = self._read_byte()
        if low is None:
            return None

        if not self._write_byte(high_cmd):
            return None
        high = self._read_byte()
        if high is None:
            return None

        low &= 0x3F
        high &= 0x3F
        return high + low / 64.0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def update(self) -> bool:
        """Request and update all AC-related values from the PIC."""
        if not self._ensure_connection():
            return False

        try:
            desired = self._read_scaled_value(0x01, 0x02)
            ambient = self._read_scaled_value(0x03, 0x04)

            if desired is not None:
                self.desiredTemperature = desired
            if ambient is not None:
                self.ambientTemperature = ambient

            # Fan speed is a single byte returned after command 0x05
            if not self._write_byte(0x05):
                return False
            fan = self._read_byte()
            if fan is not None:
                self.fanSpeed = fan

            return True
        except Exception as exc:
            print(f"Communication error in AirConditioner.update: {exc}")
            return False

    def setDesiredTemp(self, temp_celsius: float) -> bool:
        """
        Set desired temperature.

        Encodes temp_celsius as:
            temp = integral + fractional
            integral in [0, 63], fractional in steps of 1/64

        and sends two bytes:
            10t5..t0 (fractional part)
            11t5..t0 (integral part)
        """
        if not self._ensure_connection():
            return False

        # Clamp to representable range
        if temp_celsius < 0.0:
            temp_celsius = 0.0
        if temp_celsius > 63.984375:  # 63 + 63/64
            temp_celsius = 63.984375

        integral = int(temp_celsius)
        frac = int(round((temp_celsius - integral) * 64.0))

        # Round-up correction
        if frac == 64:
            frac = 0
            integral = min(integral + 1, 63)

        integral &= 0x3F
        frac &= 0x3F

        cmd_frac = 0x80 | frac  # 10xxxxxx
        cmd_int = 0xC0 | integral  # 11xxxxxx

        try:
            if not self._write_byte(cmd_frac):
                return False
            if not self._write_byte(cmd_int):
                return False

            # Local cache is updated immediately; next update() ile teyit edilir.
            self.desiredTemperature = integral + frac / 64.0
            return True
        except Exception as exc:
            print(f"Communication error in AirConditioner.setDesiredTemp: {exc}")
            return False

    # Getter methods used by console / GUI layers
    def getDesiredTemp(self) -> float:
        return self.desiredTemperature

    def getAmbientTemp(self) -> float:
        return self.ambientTemperature

    def getFanSpeed(self) -> int:
        return self.fanSpeed
