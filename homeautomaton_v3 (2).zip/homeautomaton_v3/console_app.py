# console_app.py
# Simple console-based application for manual testing.

from air_conditioner_system_connection import AirConditionerSystemConnection
from curtain_control_system_connection import CurtainControlSystemConnection


def main():
    print("Home Automation System Console Application")

    # Kullanıcı isterse buradan portları değiştirebilir
    ac = AirConditionerSystemConnection(port="COM9", baudrate=9600)
    curtain = CurtainControlSystemConnection(port="COM7", baudrate=9600)

    ac_ok = ac.open()
    curtain_ok = curtain.open()

    if not (ac_ok or curtain_ok):
        print("ERROR: Could not open any serial ports. Exiting.")
        return

    while True:
        print("\n--- Main Menu ---")
        print("1) Show current values")
        print("2) Set desired AC temperature")
        print("3) Set desired curtain status")
        print("4) Exit")

        choice = input("Select an option: ").strip()

        if choice == "1":
            if ac_ok:
                ac.update()
                print(f"Desired Temp     : {ac.getDesiredTemp():.2f} °C")
                print(f"Ambient Temp     : {ac.getAmbientTemp():.2f} °C")
                print(f"Fan Speed        : {ac.getFanSpeed():d} rps")
            else:
                print("AC board not connected.")

            if curtain_ok:
                curtain.update()
                print(f"Curtain Status   : {curtain.getCurtainStatus():.2f} %")
                print(f"Outdoor Temp     : {curtain.getOutdoorTemp():.2f} °C")
                print(f"Outdoor Pressure : {curtain.getOutdoorPress():.2f}")
                print(f"Light Intensity  : {curtain.getLightIntensity():.2f}")
            else:
                print("Curtain board not connected.")

        elif choice == "2" and ac_ok:
            try:
                t = float(input("Enter desired temperature (°C): "))
                if ac.setDesiredTemp(t):
                    print("Desired temperature command sent.")
                else:
                    print("Failed to send desired temperature.")
            except ValueError:
                print("Invalid value.")

        elif choice == "3" and curtain_ok:
            try:
                s = float(input("Enter desired curtain status (0–100 %): "))
                if curtain.setCurtainStatus(s):
                    print("Desired curtain status command sent.")
                else:
                    print("Failed to send curtain status.")
            except ValueError:
                print("Invalid value.")

        elif choice == "4":
            print("Exiting application.")
            break
        else:
            print("Invalid choice or board not connected.")

    ac.close()
    curtain.close()


if __name__ == "__main__":
    main()
