# test_api.py
# Simple script to test the Python API classes without GUI.

from air_conditioner_system_connection import AirConditionerSystemConnection
from curtain_control_system_connection import CurtainControlSystemConnection


def test_air_conditioner():
    print("=== Testing AirConditionerSystemConnection ===")
    ac = AirConditionerSystemConnection(port="COM9", baudrate=9600)
    if not ac.open():
        print("Could not open AC port.")
        return

    # Set and then read back values
    if ac.setDesiredTemp(23.5):
        print("Set desired temperature to 23.5 °C.")
    if ac.update():
        print(f"Desired Temp : {ac.getDesiredTemp():.2f} °C")
        print(f"Ambient Temp : {ac.getAmbientTemp():.2f} °C")
        print(f"Fan Speed    : {ac.getFanSpeed():d} rps")

    ac.close()
    print("AirConditioner test completed.\n")


def test_curtain_control():
    print("=== Testing CurtainControlSystemConnection ===")
    curtain = CurtainControlSystemConnection(port="COM10", baudrate=9600)
    if not curtain.open():
        print("Could not open Curtain port.")
        return

    if curtain.setCurtainStatus(50.0):
        print("Set curtain status to 50.0 %.")
    if curtain.update():
        print(f"Curtain Status  : {curtain.getCurtainStatus():.2f} %")
        print(f"Outdoor Temp    : {curtain.getOutdoorTemp():.2f} °C")
        print(f"Outdoor Pressure: {curtain.getOutdoorPress():.2f}")
        print(f"Light Intensity : {curtain.getLightIntensity():.2f}")

    curtain.close()
    print("CurtainControl test completed.\n")


if __name__ == "__main__":
    test_air_conditioner()
    test_curtain_control()
