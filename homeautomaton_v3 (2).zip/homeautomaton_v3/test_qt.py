# test_qt.py
import sys
from PyQt5.QtWidgets import QApplication, QLabel

app = QApplication(sys.argv)
label = QLabel("Merhaba PyQt")
label.resize(200, 50)
label.show()
app.exec_()
