# gui_app.py


import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QGridLayout, QDoubleSpinBox,
    QLineEdit, QGroupBox, QTabWidget, QSpinBox
)
from PyQt5.QtCore import QTimer

from air_conditioner_system_connection import AirConditionerSystemConnection
from curtain_control_system_connection import CurtainControlSystemConnection


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Home Automation Control Panel")
        self.setMinimumSize(750, 420)

        # ---------- Koyu tema / renk düzeni ----------
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #141414;
                color: #e5e5e5;
                font-family: Segoe UI;
                font-size: 10pt;
            }
            QGroupBox {
                font-weight: bold;
                border: 1px solid #2c2c2c;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 10px;
                background-color: #1a1a1a;
                color: #dcdcdc;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 4px;
                background-color: #141414;
                color: #f0f0f0;
            }
            QLabel {
                font-size: 10pt;
                color: #e5e5e5;
            }
            QTabWidget::pane {
                border: 1px solid #2c2c2c;
                border-radius: 6px;
                margin-top: -2px;
            }
            QTabBar::tab {
                padding: 6px 14px;
                margin: 2px;
                border-radius: 6px;
                background-color: #1d1d1d;
                color: #dcdcdc;
            }
            QTabBar::tab:selected {
                background-color: #2a2a2a;
                color: white;
            }
            QTabBar::tab:hover {
                background-color: #252525;
            }
            QPushButton {
                background-color: #2563eb;
                color: white;
                border-radius: 6px;
                padding: 4px 12px;
                border: none;
            }
            QPushButton:hover {
                background-color: #1e4ed3;
            }
            QPushButton:pressed {
                background-color: #173ea2;
            }
            QPushButton:disabled {
                background-color: #3b3b3b;
                color: #888;
            }
            QLineEdit, QSpinBox, QDoubleSpinBox {
                background-color: #1c1c1c;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 2px 4px;
                color: #e5e5e5;
            }
            QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {
                border: 1px solid #2563eb;
            }
        """)

        # ---------- API nesneleri ----------
        self.ac_conn = AirConditionerSystemConnection(port="COM9", baudrate=9600)
        self.curtain_conn = CurtainControlSystemConnection(port="COM7", baudrate=9600)
        self.ac_connected = False
        self.curtain_connected = False

        # ---------- Ana layout ----------
        central = QWidget()
        main_layout = QVBoxLayout()
        central.setLayout(main_layout)
        self.setCentralWidget(central)

        # ---------- Bağlantı ayarları ----------
        conn_group = QGroupBox("Connection Settings")
        conn_layout = QGridLayout()

        conn_layout.addWidget(QLabel("AC Port:"), 0, 0)
        self.ac_port_edit = QLineEdit("COM9")
        conn_layout.addWidget(self.ac_port_edit, 0, 1)

        conn_layout.addWidget(QLabel("Curtain Port:"), 0, 2)
        self.curtain_port_edit = QLineEdit("COM7")
        conn_layout.addWidget(self.curtain_port_edit, 0, 3)

        conn_layout.addWidget(QLabel("Baudrate:"), 1, 0)
        self.baud_edit = QSpinBox()
        self.baud_edit.setRange(1200, 115200)
        self.baud_edit.setValue(9600)
        conn_layout.addWidget(self.baud_edit, 1, 1)

        self.lbl_conn_status = QLabel("Status: Disconnected")
        conn_layout.addWidget(self.lbl_conn_status, 1, 2)

        self.btn_connect = QPushButton("Connect")
        self.btn_connect.setCheckable(True)
        self.btn_connect.clicked.connect(self.toggle_connection)
        conn_layout.addWidget(self.btn_connect, 1, 3)

        conn_group.setLayout(conn_layout)
        main_layout.addWidget(conn_group)

        # ---------- Sekmeler ----------
        tabs = QTabWidget()
        tabs.addTab(self._create_ac_tab(), "Air Conditioner")
        tabs.addTab(self._create_curtain_tab(), "Curtain Control")
        main_layout.addWidget(tabs)

        # ---------- Periyodik update ----------
        self.timer = QTimer(self)
        self.timer.setInterval(1000)  # ms
        self.timer.timeout.connect(self.update_readings)

    # ---------------- Air Conditioner Tab ----------------
    def _create_ac_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        display_group = QGroupBox("Current Values")
        grid = QGridLayout()

        self.lbl_desired_temp = QLabel("-- °C")
        self.lbl_ambient_temp = QLabel("-- °C")
        self.lbl_fan_speed = QLabel("-- rps")

        grid.addWidget(QLabel("Desired Temperature:"), 0, 0)
        grid.addWidget(self.lbl_desired_temp, 0, 1)

        grid.addWidget(QLabel("Ambient Temperature:"), 1, 0)
        grid.addWidget(self.lbl_ambient_temp, 1, 1)

        grid.addWidget(QLabel("Fan Speed:"), 2, 0)
        grid.addWidget(self.lbl_fan_speed, 2, 1)

        display_group.setLayout(grid)
        layout.addWidget(display_group)

        control_group = QGroupBox("Set Desired Temperature")
        h = QHBoxLayout()

        self.spin_desired_temp = QDoubleSpinBox()
        self.spin_desired_temp.setRange(10.0, 50.0)
        self.spin_desired_temp.setDecimals(2)
        self.spin_desired_temp.setSingleStep(0.5)
        self.spin_desired_temp.setValue(25.0)

        btn_set_temp = QPushButton("Send")
        btn_set_temp.clicked.connect(self.set_desired_temp)

        h.addWidget(QLabel("Temp (°C):"))
        h.addWidget(self.spin_desired_temp)
        h.addWidget(btn_set_temp)

        control_group.setLayout(h)
        layout.addWidget(control_group)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    # ---------------- Curtain Tab ----------------
    def _create_curtain_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        display_group = QGroupBox("Current Values")
        grid = QGridLayout()

        self.lbl_desired_curtain = QLabel("-- %")
        self.lbl_outdoor_temp = QLabel("-- °C")
        self.lbl_outdoor_press = QLabel("-- hPa")
        self.lbl_light_intensity = QLabel("--")

        grid.addWidget(QLabel("Desired Curtain Status:"), 0, 0)
        grid.addWidget(self.lbl_desired_curtain, 0, 1)

        grid.addWidget(QLabel("Outdoor Temperature:"), 1, 0)
        grid.addWidget(self.lbl_outdoor_temp, 1, 1)

        grid.addWidget(QLabel("Outdoor Pressure:"), 2, 0)
        grid.addWidget(self.lbl_outdoor_press, 2, 1)

        grid.addWidget(QLabel("Light Intensity:"), 3, 0)
        grid.addWidget(self.lbl_light_intensity, 3, 1)

        display_group.setLayout(grid)
        layout.addWidget(display_group)

        control_group = QGroupBox("Set Desired Curtain Status")
        h = QHBoxLayout()

        self.spin_curtain = QDoubleSpinBox()
        self.spin_curtain.setRange(0.0, 100.0)
        self.spin_curtain.setDecimals(2)
        self.spin_curtain.setSingleStep(1.0)
        self.spin_curtain.setValue(50.0)

        btn_set_curtain = QPushButton("Send")
        btn_set_curtain.clicked.connect(self.set_desired_curtain)

        h.addWidget(QLabel("Curtain (% closed):"))
        h.addWidget(self.spin_curtain)
        h.addWidget(btn_set_curtain)

        control_group.setLayout(h)
        layout.addWidget(control_group)

        layout.addStretch()
        tab.setLayout(layout)
        return tab

    # ---------------- Connection management ----------------
    def toggle_connection(self):
        if self.btn_connect.isChecked():
            self.open_ports()
        else:
            self.close_ports()

    def open_ports(self):
        # GUI'den port ve baudrate al
        self.ac_conn.setComPort(self.ac_port_edit.text())
        self.curtain_conn.setComPort(self.curtain_port_edit.text())
        self.ac_conn.setBaudRate(self.baud_edit.value())
        self.curtain_conn.setBaudRate(self.baud_edit.value())

        self.ac_connected = self.ac_conn.open()
        self.curtain_connected = self.curtain_conn.open()

        if self.ac_connected or self.curtain_connected:
            self.lbl_conn_status.setText("Status: Connected")
            self.btn_connect.setText("Disconnect")
            self.timer.start()
        else:
            self.btn_connect.setChecked(False)
            self.lbl_conn_status.setText("Status: Connection Failed")
            self.btn_connect.setText("Connect")

    def close_ports(self):
        self.timer.stop()

        if self.ac_connected:
            self.ac_conn.close()
            self.ac_connected = False
        if self.curtain_connected:
            self.curtain_conn.close()
            self.curtain_connected = False

        self.lbl_conn_status.setText("Status: Disconnected")
        self.btn_connect.setText("Connect")

    # ---------------- Periodik okuma ----------------
    def update_readings(self):
        if self.ac_connected:
            self.ac_conn.update()
            self.lbl_desired_temp.setText(f"{self.ac_conn.getDesiredTemp():.2f} °C")
            self.lbl_ambient_temp.setText(f"{self.ac_conn.getAmbientTemp():.2f} °C")
            self.lbl_fan_speed.setText(f"{self.ac_conn.getFanSpeed():d} rps")

        if self.curtain_connected:
            self.curtain_conn.update()
            self.lbl_desired_curtain.setText(f"{self.curtain_conn.getCurtainStatus():.2f} %")
            self.lbl_outdoor_temp.setText(f"{self.curtain_conn.getOutdoorTemp():.2f} °C")
            self.lbl_outdoor_press.setText(f"{self.curtain_conn.getOutdoorPress():.2f} hPa")
            self.lbl_light_intensity.setText(f"{self.curtain_conn.getLightIntensity():.2f}")

    # ---------------- Komut gönderme ----------------
    def set_desired_temp(self):
        if not self.ac_connected:
            return
        temp = float(self.spin_desired_temp.value())
        self.ac_conn.setDesiredTemp(temp)

    def set_desired_curtain(self):
        if not self.curtain_connected:
            return
        val = float(self.spin_curtain.value())
        self.curtain_conn.setCurtainStatus(val)


def main():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
