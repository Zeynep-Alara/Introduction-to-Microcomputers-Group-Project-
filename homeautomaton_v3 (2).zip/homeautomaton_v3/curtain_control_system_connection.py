# curtain_control_system_connection.py
# High-level API for the Curtain Control board.

from home_automation_system_connection import HomeAutomationSystemConnection


class CurtainControlSystemConnection(HomeAutomationSystemConnection):
    """
    Implements the PC-side API for the curtain & outdoor environment subsystem.

    - R2.2.6: Read desired curtain status, outdoor temperature, pressure
              and light intensity using command bytes 0x01–0x08.
    - R2.2.7: Set desired curtain status using two 6-bit command bytes
              (10c5..c0 and 11c5..c0).
    """

    def __init__(self, port: str | None = None, baudrate: int = 9600) -> None:
        super().__init__(port, baudrate)
        self.curtainStatus: float = 0.0       # 0–100%
        self.outdoorTemperature: float = 0.0
        self.outdoorPressure: float = 0.0
        self.lightIntensity: float = 0.0

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _read_scaled_value(self, low_cmd: int, high_cmd: int) -> float | None:
        """
        Read a fixed-point value encoded as two 6-bit bytes
        (value = high + low / 64.0).
        """
        if not self._write_byte(low_cmd):
            return None
        low = self._read_byte()
        if low is None:
            return None

        if not self._write_byte(high_cmd):
            return None
        high = self._read_byte()
        if high is None:
            return None

        low &= 0x3F
        high &= 0x3F
        return high + low / 64.0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def update(self) -> bool:
        """Request and update all curtain & environment values."""
        if not self._ensure_connection():
            return False

        try:
            status = self._read_scaled_value(0x01, 0x02)
            temp = self._read_scaled_value(0x03, 0x04)
            press = self._read_scaled_value(0x05, 0x06)
            light = self._read_scaled_value(0x07, 0x08)

            if status is not None:
                self.curtainStatus = status
            if temp is not None:
                self.outdoorTemperature = temp
            if press is not None:
                self.outdoorPressure = press
            if light is not None:
                self.lightIntensity = light

            return True
        except Exception as exc:
            print(f"Communication error in CurtainControl.update: {exc}")
            return False

    def setCurtainStatus(self, status_percent: float) -> bool:
        """
        Set desired curtain status (0–100%).

        Encodes status_percent as:
            val = integral + fractional
            integral in [0, 63], fractional in steps of 1/64

        and sends:
            10c5..c0 (fractional part)
            11c5..c0 (integral part)
        """
        if not self._ensure_connection():
            return False

        if status_percent < 0.0:
            status_percent = 0.0
        if status_percent > 100.0:
            status_percent = 100.0

        integral = int(status_percent)
        frac = int(round((status_percent - integral) * 64.0))

        if frac == 64:
            frac = 0
            integral = min(integral + 1, 63)

        integral &= 0x3F
        frac &= 0x3F

        cmd_frac = 0x80 | frac  # 10xxxxxx
        cmd_int = 0xC0 | integral  # 11xxxxxx

        try:
            if not self._write_byte(cmd_frac):
                return False
            if not self._write_byte(cmd_int):
                return False

            self.curtainStatus = integral + frac / 64.0
            return True
        except Exception as exc:
            print(f"Communication error in CurtainControl.setCurtainStatus: {exc}")
            return False

    # Getter methods
    def getOutdoorTemp(self) -> float:
        return self.outdoorTemperature

    def getOutdoorPress(self) -> float:
        return self.outdoorPressure

    def getLightIntensity(self) -> float:
        return self.lightIntensity

    def getCurtainStatus(self) -> float:
        return self.curtainStatus
